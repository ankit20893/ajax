<?php
@session_start();
ob_start();
if(!isset($_SESSION['user_session']))
{
 header("Location: index.php");
}

include_once 'dbconfig.php';
$id=$_SESSION['user_session'];
$sql="SELECT * FROM tbl_users WHERE user_id=$id";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);


?>
<style>
	#section {
    width:350px;
    float:left;
    padding:10px;
}
#nav {
    line-height:50px;
    background-color:#eeeeee;
    height:300px;
    width:210px;
    float:left;
    padding:5px;
}
</style>
<div id="nav">

<?php if($row["profilePic"]=="") {
        echo "<img src='uploads/default.jpg' title='default user' style='width:200px;height:228px;'>";
	
	?>
        <a href="upload.php?id=<?php echo $row["id"];?>">plz upload photo</a>
    <?php
}
    else{
		$dir="uploads";
		echo '<img src="', $dir, '/', $row['profilePic'], '" alt="', $row['profilePic'], '" />';
       // echo "<img src='uploads/'.$row['profilePic']>";
       ?>
   
       <a href="upload.php?id=<?php echo $row["id"];?>">upload photo</a>
       <?php
    }
    ?>
</div>
<div class="section">


    <div class='alert alert-success'>
  <button class='close' data-dismiss='alert'>&times;</button>
   <strong>Hello '<?php echo $row['first_name']." ".$row['last_name']; ?></strong>  Welcome to the members page.
   <strong><a href="logout.php">logout</a></strong>
    </div>


<div class="col-md-4">
<table class="table">
  <tr>
      <td><strong>UserName</strong></td>
      <td><?echo $row['user_name']; ?></td>
  </tr>
  <tr>
      <td><strong>Name</strong></strong></td>
      <td><?php echo $row['first_name']."  ".$row['last_name']; ?></td>
   </tr>
   <tr>
       <td><strong>Email</strong></td>
       <td><?php echo $row['user_email']; ?></td>
   </tr>  
   <tr>
       <td><strong>Joining Date</strong></td>
       <td><?echo $row['joining_date']?></td>
   </tr> 
</table>
</div>
</div>
