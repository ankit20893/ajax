<?php
$conn=mysqli_connect("localhost","Tr_AnkitSingh","mobi123DB","Tr_AnkitSingh_03May16_Ravi");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>